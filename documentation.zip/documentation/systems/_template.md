# System: <Codename> — <Purpose>

## Identity
- Tier: Core|Supporting
- Owner: Platform
- Status: Active

## Interfaces
- Inputs:
- Outputs:

## Dependencies
- Depends on:
- Used by:

## Deployment
- Location:
- Notes:

## Rules
- Key constraints:

## Links
- Back: ../..

---


