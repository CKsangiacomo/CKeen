# System: Cairo — Custom Domains
## Identity
- Tier: Supporting
- Purpose: Custom domain management
## Interfaces
- Domain provisioning APIs
## Dependencies
- Used by: Site, Bob
## Deployment
- c-keen-app
## Rules
- Enforce HTTPS; auto-renew certificates
## Links
- Back: ../../CONTEXT.md
