# System: Copenhagen — AI Service
## Identity
- Tier: Core
- Purpose: Centralized AI orchestration for all systems
## Interfaces
- Edge functions; request brokering
## Dependencies
- Used by: Bob, Paris
## Deployment
- Supabase Edge Functions
## Rules
- All AI calls centralized here
## Links
- Back: ../../CONTEXT.md
