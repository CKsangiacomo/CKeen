# System: Helsinki — Analytics Warehouse
## Identity
- Tier: Supporting
- Purpose: BI and analytics aggregates
## Interfaces
- ETL jobs, query endpoints
## Dependencies
- Depends on: Michael
- Used by: App, Site
## Deployment
- Supabase (warehouse)
## Rules
- Aggregates only; no PII persistence without approval
## Links
- Back: ../../CONTEXT.md
