# System: Milan — Localization
## Identity
- Tier: Supporting
- Purpose: i18n, language routing
## Interfaces
- Translation bundles, locale resolver
## Dependencies
- Used by: App, Site, Venice
## Deployment
- c-keen-app and c-keen-site
## Rules
- Default locale en-US, lazy-load others
## Links
- Back: ../../CONTEXT.md
