# System: Prague — Marketplace & Discovery
## Identity
- Tier: Supporting
- Purpose: SEO, gallery and discovery
## Interfaces
- Public gallery pages; search endpoints
## Dependencies
- Used by: Site
## Deployment
- c-keen-site
## Rules
- Fast, static-first pages
## Links
- Back: ../../CONTEXT.md
