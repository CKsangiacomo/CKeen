# System: Stockholm — Growth & Experimentation
## Identity
- Tier: Supporting
- Purpose: A/B tests, feature flags
## Interfaces
- Flag evaluation API, experiments dashboard
## Dependencies
- Used by: App, Site
## Deployment
- c-keen-app
## Rules
- Kill switches must be safe-by-default
## Links
- Back: ../../CONTEXT.md
